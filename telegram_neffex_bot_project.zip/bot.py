import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, WebAppInfo
from aiogram.utils import executor

API_TOKEN = 'YOUR_BOT_TOKEN'

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

# Мовні тексти
texts = {
    "ua": {
        "start": "Оберіть розділ:",
        "project": "Проєкти",
        "bio": "Біо",
        "contact": "Звʼязок",
        "bio_text": """ʙɪᴏ | ɴᴇғғᴇx\n\nᴍᴀɪɴ ᴀᴄᴄᴏᴜɴᴛ\nt.me/bestcrimes\n\nᴍᴀɪɴ ᴄʜᴀɴɴᴇʟ 🔫:\nʼʼНе даю канал ʼʼ\n\nᴄᴏᴜɴᴛʀʏ : 🇺🇦\n\nadvertisement:\n@neffexcall_bot\n\nATTENTION ❗️\nhttps://telegra.ph/ATTENTION-03-19-16\n\nᴘʀɪᴄᴇ: I ᴅᴏɴ'ᴛ ᴅᴏ ᴛʜɪs #ᴘʀᴏᴛʏsᴠᴀᴛᴀᴘᴏᴜᴋʀᴀɪɴɪ ɪ ᴏɴʟʏ ʜᴇʟᴘ ᴘᴇᴏᴘʟᴇ""",
        "contact_text": "@neffexcall_bot — бот для забанених і амністій\n@bestcrimes — аккаунт менеджера"
    }
}

# Вибір мови (тільки ua реалізовано зараз)
@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add(KeyboardButton(texts["ua"]["project"], web_app=WebAppInfo(url="https://example.com")))
    kb.add(KeyboardButton(texts["ua"]["bio"]))
    kb.add(KeyboardButton(texts["ua"]["contact"]))
    await message.answer(texts["ua"]["start"], reply_markup=kb)

@dp.message_handler(lambda message: message.text == texts["ua"]["bio"])
async def bio(message: types.Message):
    await message.answer(texts["ua"]["bio_text"])

@dp.message_handler(lambda message: message.text == texts["ua"]["contact"])
async def contact(message: types.Message):
    await message.answer(texts["ua"]["contact_text"])

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
